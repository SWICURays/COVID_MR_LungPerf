function opennii(nii)
imtool3D_nii_3planes(nii)